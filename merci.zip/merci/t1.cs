//Rextester.Program.Main is the entry point for your code. Don't change it.
//Compiler version 4.0.30319.17929 for Microsoft (R) .NET Framework 4.5

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Rextester{
    
    public class Perso
    {
        public string Nom {get;set;}
        public string Prenom {get;set;}    
        
        
        public virtual void Spresen()
        {
            //Your code goes here
            Console.WriteLine("m/mme. {0} {1}",Nom, Prenom);
        }
    }
    
    public class avo:Perso{
        
        
        public override void Spresen()
        {
            //Your code goes here
            Console.WriteLine("Maitre. {0} {1}",Nom, Prenom);
        }
    }
    
    class program{
        //public 
         static void Main(string[] args){
        
            avo a= new avo{Nom="jean", Prenom="martin"};
            Perso p= new Perso{Nom="Rom", Prenom="Robert"};
            Perso ap= new avo{Nom="Delph", Prenom="Lu"};
            a.Spresen();
            p.Spresen();
            ap.Spresen();
        
        }
    
    
    }
    
}


---------------------------


