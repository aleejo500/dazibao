using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Rextester{
    
    public struct Perso
    {
        public int Age {get;set;}
        public string Nom {get;set;}    
        
    }
    
    
    class program{
	
		 public Perso(struct Perso,int agePersonne, string nomPersonne)
        {
            //Your code goes here
            p.Age=agePersonne;
			p.Nom=nomPersonne;
        }
	
        public static void Main(string[] args){
                           
            Perso p= new Perso();
			Perso(p,10, "Thomas");
            
            Console.WriteLine("nom. {0}  age. {1}", p.Nom, p.Age);
        }
    }
    
}

--------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace Rextester{
    
    public struct Perso
    {
        public int Age {get;set;}
        public string Nom {get;set;}    
        
    }
    
    
    class program{
	
		 static void Person(Perso p,int agePersonne, string nomPersonne)
        {
            //Your code goes here
            p.Age=agePersonne;
			p.Nom=nomPersonne;
        }
	
        public static void Main(string[] args){
                           
            Perso p= new Perso();
            
			Person(p, 10, "Thomas");
            
            Console.WriteLine("nom. {0}  age. {1}", p.Nom, p.Age);
        }
    }
    
}

---------------------------------------



 public struct Perso
    {
        public int Age {get;set;}
        public string Nom {get;set;}  
        
         public void Person(int agePersonne, string nomPersonne)
        {
            //Your code goes here
            Age=agePersonne;
			Nom=nomPersonne;
        }       
    }
    
    
   class Program
   {
       public static void Main(string[] args){
                           
            Perso p= new Perso();
            
			p.Person(10, "Thomas");
            
            Console.WriteLine("nom. {0}  age. {1}", p.Nom, p.Age);
        }
        
        
    }