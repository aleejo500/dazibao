class Dossier:IComparable
    {
        public int ID {get;set;}
        public double Encours {get;set;}  
        
                
    }
    
    
   class Program
   {
       public static void Main(string[] args){
                           
         
        }
        
        
    }